import React, { useState } from 'react';
import { SAMPLE_MATCHES } from '../data/mockData';
import { SportsMatch, BetslipItem, SessionMetrics } from '../types';
import { 
  Sparkles, 
  Info, 
  CheckCircle2, 
  TrendingUp, 
  Shield, 
  ChevronRight, 
  Clock, 
  Bookmark, 
  Bell, 
  AlertCircle,
  HelpCircle,
  X,
  ArrowRight,
  Flame,
  Filter,
  Check
} from 'lucide-react';

interface PSKPrototypeProps {
  metrics: SessionMetrics;
  setMetrics: React.Dispatch<React.SetStateAction<SessionMetrics>>;
}

export const PSKPrototype: React.FC<PSKPrototypeProps> = ({ metrics, setMetrics }) => {
  const [activeIntent, setActiveIntent] = useState<'express' | 'analytical' | 'inplay'>('express');
  const [selectedSport, setSelectedSport] = useState<string>('all');
  const [expandedClarityMatchId, setExpandedClarityMatchId] = useState<string | null>('m1');
  const [betslip, setBetslip] = useState<BetslipItem[]>([
    {
      matchId: 'm1',
      matchTitle: 'GNK Dinamo Zagreb vs HNK Hajduk Split',
      selection: 'Dinamo Zagreb (Home Win)',
      odds: 1.85,
      marketName: 'Match Winner 1X2',
      clarityNote: 'Backed by Maksimir home record (0.7 goals conceded/match)',
    }
  ]);
  const [stake, setStake] = useState<number>(5);
  const [showConfirmationSuccess, setShowConfirmationSuccess] = useState<boolean>(false);
  const [savedToWatchlist, setSavedToWatchlist] = useState<boolean>(false);
  const [alertSet, setAlertSet] = useState<boolean>(false);

  // Filter matches based on selected intent & sport
  const filteredMatches = SAMPLE_MATCHES.filter((m) => {
    if (selectedSport !== 'all' && m.sport !== selectedSport) return false;
    if (activeIntent === 'inplay') return m.isLive;
    return true;
  });

  // Calculate Betslip odds and net potential payout with transparent Croatian tax calculation
  const totalOdds = betslip.reduce((acc, item) => acc * item.odds, 1);
  const grossReturn = (stake * totalOdds);
  const grossProfit = Math.max(0, grossReturn - stake);
  // Croatian Tax Law (Zakon o igrama na sreću): 10% on profit up to €1,327
  const estimatedTax = grossProfit * 0.10;
  const netReturn = grossReturn - estimatedTax;

  const handleAddSelection = (match: SportsMatch, selectionName: string, odds: number, marketName: string) => {
    const existingIndex = betslip.findIndex((item) => item.matchId === match.id);
    const newItem: BetslipItem = {
      matchId: match.id,
      matchTitle: `${match.homeTeam} vs ${match.awayTeam}`,
      selection: selectionName,
      odds,
      marketName,
      clarityNote: match.clarityInsights.summary,
    };

    if (existingIndex > -1) {
      const updated = [...betslip];
      updated[existingIndex] = newItem;
      setBetslip(updated);
    } else {
      setBetslip([...betslip, newItem]);
    }

    // Update SQI telemetry
    setMetrics((prev) => ({
      ...prev,
      actionsCompleted: prev.actionsCompleted + 1,
      sqiScore: Math.min(98, prev.sqiScore + 4),
      confidenceIndicator: Math.min(95, prev.confidenceIndicator + 6),
    }));
  };

  const handleRemoveSelection = (matchId: string) => {
    setBetslip(betslip.filter((item) => item.matchId !== matchId));
  };

  const handleConfirmAction = () => {
    setShowConfirmationSuccess(true);
    setMetrics((prev) => ({
      ...prev,
      actionsCompleted: prev.actionsCompleted + 1,
      sqiScore: Math.min(100, prev.sqiScore + 10),
      frictionPointsAvoided: prev.frictionPointsAvoided + 2,
    }));
  };

  const handleSaveWatchlist = () => {
    setSavedToWatchlist(true);
    setMetrics((prev) => ({
      ...prev,
      sqiScore: Math.min(95, prev.sqiScore + 5),
      frictionPointsAvoided: prev.frictionPointsAvoided + 1,
    }));
    setTimeout(() => setSavedToWatchlist(false), 3000);
  };

  const handleSetAlert = () => {
    setAlertSet(true);
    setTimeout(() => setAlertSet(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#001726] text-slate-100">
      {/* Sub-header mimicking PSK.hr live navigation */}
      <div className="bg-[#00223B] border-b border-[#003B64] px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-6 text-sm font-semibold">
            <span className="text-[#FFB800] border-b-2 border-[#FFB800] pb-1 cursor-pointer">SPORT</span>
            <span className="text-slate-300 hover:text-white cursor-pointer flex items-center gap-1">
              UŽIVO (LIVE) <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            </span>
            <span className="text-slate-400 hover:text-white cursor-pointer hidden md:inline">CASINO</span>
            <span className="text-slate-400 hover:text-white cursor-pointer hidden md:inline">VEGAS</span>
            <span className="text-slate-400 hover:text-white cursor-pointer hidden lg:inline">LOTO</span>
            <span className="text-slate-400 hover:text-white cursor-pointer hidden lg:inline">REZULTATI</span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <span className="text-slate-400">Balance:</span>
            <span className="bg-[#001726] px-2.5 py-1 rounded text-emerald-400 font-mono font-bold border border-[#003B64]">
              €148.50
            </span>
            <span className="text-slate-500">|</span>
            <div className="flex items-center gap-1 text-slate-300">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] text-emerald-400 font-medium">Daily Limit: €25.00</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Solution Pillar 1 Banner: Intent Lens (Combats Discovery Friction) */}
        <div className="mb-6 bg-gradient-to-r from-[#002D4E] to-[#001F36] border border-[#005088] rounded-xl p-4 sm:p-5 shadow-lg">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-[#FFB800] text-[#001D33] text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
                  ClarityCore™ Innovation
                </span>
                <span className="text-xs text-sky-300 font-medium flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Adaptive Intent Lens (Zero Discovery Friction)
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                Personalized Relevance Without Invasive Tracking
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                First-time visitors see curated high-confidence derbies; veterans unlock deep tactical xG models.
              </p>
            </div>

            {/* Intent Switcher Pill */}
            <div className="flex items-center bg-[#001726] p-1 rounded-lg border border-[#003B64] self-start md:self-center">
              <button
                id="intent-express"
                onClick={() => setActiveIntent('express')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeIntent === 'express'
                    ? 'bg-[#005088] text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>Express Matchday</span>
              </button>

              <button
                id="intent-analytical"
                onClick={() => setActiveIntent('analytical')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeIntent === 'analytical'
                    ? 'bg-[#005088] text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
                <span>Tactical & Analytics</span>
              </button>

              <button
                id="intent-inplay"
                onClick={() => setActiveIntent('inplay')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeIntent === 'inplay'
                    ? 'bg-[#005088] text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-red-400" />
                <span>In-Play Momentum</span>
              </button>
            </div>
          </div>
        </div>

        {/* 3-Column Layout: Categories / Matches / Smart Reassurance Betslip */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Quick Filters */}
          <div className="lg:col-span-3 space-y-4">
            <div className="bg-[#00223B] border border-[#003B64] rounded-xl p-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-[#FFB800]" />
                Kategorije (Sports)
              </h3>
              <div className="space-y-1">
                {[
                  { id: 'all', name: 'Sve (All Highlights)', count: 5 },
                  { id: 'football', name: 'Nogomet (Football)', count: 4 },
                  { id: 'tennis', name: 'Tenis (ATP)', count: 1 },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedSport(s.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      selectedSport === s.id
                        ? 'bg-[#005088] text-white font-semibold'
                        : 'text-slate-300 hover:bg-[#002D4E]'
                    }`}
                  >
                    <span>{s.name}</span>
                    <span className="text-[10px] bg-[#001726] px-1.5 py-0.5 rounded text-slate-400">
                      {s.count}
                    </span>
                  </button>
                ))}
              </div>

              {/* Croatian League Feature Highlight */}
              <div className="mt-5 pt-4 border-t border-[#003B64]">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-red-500"></span>
                  <span className="text-xs font-bold text-slate-200">SuperSport HNL</span>
                </div>
                <div className="bg-[#001726] p-2.5 rounded-lg border border-[#003B64] text-xs space-y-1 text-slate-300">
                  <div className="flex justify-between">
                    <span>Dinamo Zagreb</span>
                    <span className="font-mono text-emerald-400">1.85</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Hajduk Split</span>
                    <span className="font-mono text-amber-400">4.20</span>
                  </div>
                  <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                    Maksimir Stadium • 20:00 CEST
                  </div>
                </div>
              </div>

              {/* Responsible Play Badge */}
              <div className="mt-4 p-3 bg-emerald-950/40 border border-emerald-800/40 rounded-lg text-xs text-emerald-300">
                <div className="flex items-center gap-1.5 font-semibold text-emerald-200 mb-1">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Odgovorno Igranje (EU RG)</span>
                </div>
                <p className="text-[11px] text-emerald-400/80 leading-relaxed">
                  No artificial countdowns. No auto-betting. You are always in control.
                </p>
              </div>
            </div>

            {/* Live Session Telemetry Card for Hackathon Judges */}
            <div className="bg-[#001F36] border border-[#004A7F] rounded-xl p-4 text-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-sky-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Session Telemetry (Real-Time)
                </span>
                <span className="text-[10px] bg-sky-900/60 text-sky-200 px-1.5 py-0.5 rounded">
                  Live
                </span>
              </div>
              <div className="space-y-2 text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Time to First Action:</span>
                  <span className="font-mono text-emerald-400 font-semibold">1m 14s (58% faster)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Decision Confidence:</span>
                  <span className="font-mono text-sky-400 font-semibold">{metrics.confidenceIndicator}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Friction Points Avoided:</span>
                  <span className="font-mono text-[#FFB800] font-semibold">{metrics.frictionPointsAvoided}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">EU RG Health Guard:</span>
                  <span className="font-mono text-emerald-400 font-semibold">{metrics.rgHealthStatus}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Column: Matches Feed with Clarity Snippets */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Istaknute Utakmice (Featured Matches)</span>
                <span className="text-xs font-normal text-slate-400">({filteredMatches.length} available)</span>
              </h3>
              <span className="text-[11px] text-sky-300 bg-[#002D4E] px-2 py-0.5 rounded border border-sky-800">
                {activeIntent === 'express' && 'Mode: Quick Clarity'}
                {activeIntent === 'analytical' && 'Mode: Deep H2H & Stats'}
                {activeIntent === 'inplay' && 'Mode: Live In-Play'}
              </span>
            </div>

            {filteredMatches.map((match) => {
              const isExpanded = expandedClarityMatchId === match.id;
              const isHomeSelected = betslip.some((b) => b.matchId === match.id && b.selection.includes('Home'));
              const isDrawSelected = betslip.some((b) => b.matchId === match.id && b.selection.includes('Draw'));
              const isAwaySelected = betslip.some((b) => b.matchId === match.id && b.selection.includes('Away'));

              return (
                <div
                  key={match.id}
                  className="bg-[#00223B] border border-[#003B64] hover:border-[#005088] rounded-xl p-4 transition-all shadow-sm"
                >
                  {/* Top Match Bar */}
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="font-medium text-slate-300">{match.league}</span>
                    <div className="flex items-center gap-2">
                      {match.isLive ? (
                        <span className="bg-red-950 text-red-300 border border-red-800 px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
                          {match.liveMinute} • {match.score}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {match.time}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Teams */}
                  <div className="mb-3">
                    <div className="flex justify-between items-center text-sm sm:text-base font-bold text-white">
                      <span>{match.homeTeam}</span>
                      {match.isLive && <span className="text-amber-400 font-mono text-base">{match.score?.split('-')[0]}</span>}
                    </div>
                    <div className="flex justify-between items-center text-sm sm:text-base font-bold text-white mt-0.5">
                      <span>{match.awayTeam}</span>
                      {match.isLive && <span className="text-amber-400 font-mono text-base">{match.score?.split('-')[1]}</span>}
                    </div>
                  </div>

                  {/* Odds Buttons */}
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    <button
                      onClick={() => handleAddSelection(match, `${match.homeTeam} (Home Win)`, match.odds.home, '1X2')}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        isHomeSelected
                          ? 'bg-[#FFB800] text-[#001D33] font-black border-[#FFB800]'
                          : 'bg-[#001726] border-[#003B64] hover:border-[#005088] text-slate-200'
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">1 (Home)</div>
                      <div className="text-xs sm:text-sm font-bold font-mono">{match.odds.home.toFixed(2)}</div>
                    </button>

                    {match.odds.draw ? (
                      <button
                        onClick={() => handleAddSelection(match, 'Draw (X)', match.odds.draw!, '1X2')}
                        className={`p-2 rounded-lg border text-center transition-all ${
                          isDrawSelected
                            ? 'bg-[#FFB800] text-[#001D33] font-black border-[#FFB800]'
                            : 'bg-[#001726] border-[#003B64] hover:border-[#005088] text-slate-200'
                        }`}
                      >
                        <div className="text-[10px] text-slate-400">X (Draw)</div>
                        <div className="text-xs sm:text-sm font-bold font-mono">{match.odds.draw.toFixed(2)}</div>
                      </button>
                    ) : (
                      <div className="p-2 rounded-lg bg-[#001726]/40 border border-slate-800 text-center text-slate-600 text-xs flex items-center justify-center">
                        N/A
                      </div>
                    )}

                    <button
                      onClick={() => handleAddSelection(match, `${match.awayTeam} (Away Win)`, match.odds.away, '1X2')}
                      className={`p-2 rounded-lg border text-center transition-all ${
                        isAwaySelected
                          ? 'bg-[#FFB800] text-[#001D33] font-black border-[#FFB800]'
                          : 'bg-[#001726] border-[#003B64] hover:border-[#005088] text-slate-200'
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">2 (Away)</div>
                      <div className="text-xs sm:text-sm font-bold font-mono">{match.odds.away.toFixed(2)}</div>
                    </button>
                  </div>

                  {/* Clarity Insights Toggle & Drawer */}
                  <div className="bg-[#00192B] rounded-lg p-2.5 border border-[#003B64]">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-xs font-semibold text-sky-200">
                          {match.clarityInsights.tag}:
                        </span>
                        <span className="text-xs text-slate-300 truncate max-w-[200px] sm:max-w-none">
                          {match.clarityInsights.statFact}
                        </span>
                      </div>
                      <button
                        onClick={() => setExpandedClarityMatchId(isExpanded ? null : match.id)}
                        className="text-[11px] text-sky-400 hover:text-sky-300 font-medium flex items-center gap-0.5 ml-2"
                      >
                        {isExpanded ? 'Less' : 'Why this pick?'}
                        <ChevronRight className={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                      </button>
                    </div>

                    {/* Expanded Detail (Combats Discovery Friction & Hidden Rules) */}
                    {isExpanded && (
                      <div className="mt-3 pt-2.5 border-t border-slate-800 text-xs space-y-2">
                        <p className="text-slate-300 leading-relaxed">
                          {match.clarityInsights.summary}
                        </p>
                        <div className="bg-[#00223B] p-2 rounded border border-[#003B64] flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-400">Fair Value Rating:</span>
                            <span className="font-semibold text-emerald-400">Grade {match.clarityInsights.confidenceGrade}</span>
                          </div>
                          <span className="text-[10px] text-slate-400">Transparent AI Analysis</span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400">
                          <span>Recent Form:</span>
                          <span className="font-mono text-emerald-400">
                            {match.h2hStats.homeRecent.join('-')}
                          </span>
                          <span>vs</span>
                          <span className="font-mono text-sky-400">
                            {match.h2hStats.awayRecent.join('-')}
                          </span>
                          <span className="ml-auto text-[10px] text-slate-500">
                            Last: {match.h2hStats.lastMeeting}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Betslip with Zero-Pressure Reassurance Flow (Pillar 2) */}
          <div className="lg:col-span-4">
            <div className="bg-[#00223B] border-2 border-[#005088] rounded-xl overflow-hidden shadow-xl sticky top-20">
              {/* Slip Header */}
              <div className="bg-[#002D4E] p-4 border-b border-[#004A7F] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                    Listić (Betslip)
                  </span>
                  <span className="bg-[#FFB800] text-[#001D33] text-xs font-bold px-1.5 py-0.2 rounded-full">
                    {betslip.length}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-700/50">
                  <Shield className="w-3 h-3" />
                  <span>Zero-Pressure Guard</span>
                </div>
              </div>

              {/* Items in Slip */}
              <div className="p-4 space-y-3 max-h-[320px] overflow-y-auto">
                {betslip.length === 0 ? (
                  <div className="text-center py-8 text-slate-400">
                    <HelpCircle className="w-8 h-8 mx-auto mb-2 text-slate-500" />
                    <p className="text-xs font-medium">Your betslip is empty.</p>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Pick any selection from the match list to see transparent calculation.
                    </p>
                  </div>
                ) : (
                  betslip.map((item) => (
                    <div
                      key={item.matchId}
                      className="bg-[#001726] border border-[#003B64] rounded-lg p-3 relative group text-xs"
                    >
                      <button
                        onClick={() => handleRemoveSelection(item.matchId)}
                        className="absolute top-2 right-2 text-slate-400 hover:text-red-400"
                        title="Remove selection"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>

                      <div className="text-slate-400 text-[11px] pr-4">{item.matchTitle}</div>
                      <div className="font-bold text-white mt-1 flex justify-between">
                        <span>{item.selection}</span>
                        <span className="font-mono text-[#FFB800]">{item.odds.toFixed(2)}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.marketName}</div>

                      <div className="mt-2 text-[10px] text-emerald-400/90 bg-emerald-950/30 p-1.5 rounded border border-emerald-800/30">
                        {item.clarityNote}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Betslip Footer with Reassurance & Calculations */}
              {betslip.length > 0 && (
                <div className="bg-[#00192B] p-4 border-t border-[#003B64] space-y-3">
                  {/* Stake selector */}
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-1.5">
                      <span>Ulog (Stake):</span>
                      <span className="text-[11px] text-emerald-400">Responsible stake suggested</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5 mb-2">
                      {[2, 5, 10, 20].map((amt) => (
                        <button
                          key={amt}
                          onClick={() => setStake(amt)}
                          className={`py-1 rounded text-xs font-mono font-bold border transition-colors ${
                            stake === amt
                              ? 'bg-[#FFB800] text-[#001D33] border-[#FFB800]'
                              : 'bg-[#00223B] border-[#003B64] text-slate-200 hover:border-[#005088]'
                          }`}
                        >
                          €{amt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Transparent Calculation Breakdown (Solves Final-Step Drop-Off!) */}
                  <div className="bg-[#00223B] p-3 rounded-lg border border-[#003B64] text-xs space-y-1.5">
                    <div className="flex justify-between text-slate-400">
                      <span>Ukupni Tečaj (Total Odds):</span>
                      <span className="font-mono text-white font-bold">{totalOdds.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Bruto Dobitak (Gross Payout):</span>
                      <span className="font-mono text-slate-300">€{grossReturn.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-slate-400 items-center">
                      <span className="flex items-center gap-1">
                        Porez (HR State Tax 10%):
                        <Info className="w-3 h-3 text-slate-500" title="Croatian law: 10% tax on net winnings up to €1,327" />
                      </span>
                      <span className="font-mono text-amber-400">-€{estimatedTax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-white font-bold pt-1 border-t border-slate-700 text-sm">
                      <span className="text-emerald-300">Čisti Dobitak (Net Payout):</span>
                      <span className="font-mono text-emerald-400 font-black">€{netReturn.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Responsible Limit Check */}
                  <div className="flex items-center gap-2 text-[11px] text-slate-300 bg-[#001726] p-2 rounded border border-[#003B64]">
                    <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>
                      This €{stake} action utilizes <strong className="text-emerald-400">{Math.round((stake/25)*100)}%</strong> of your daily limit (€25.00).
                    </span>
                  </div>

                  {/* Primary Action Button */}
                  <button
                    id="confirm-action-btn"
                    onClick={handleConfirmAction}
                    className="w-full bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-slate-950 font-bold py-3 px-4 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 text-slate-950" />
                    <span>Potvrdi s Povjerenjem (Confirm Confidently)</span>
                    <span className="font-mono text-xs bg-slate-950/20 px-1.5 py-0.5 rounded">€{stake}</span>
                  </button>

                  {/* Zero-Pressure Reassurance Exit Options (Instead of Abandonment!) */}
                  <div className="pt-2 border-t border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400 mb-2">
                      Not ready to confirm? No pressure — keep value in this session:
                    </p>
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={handleSaveWatchlist}
                        className="px-2.5 py-1.5 rounded bg-[#00223B] border border-[#003B64] hover:border-slate-500 text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                      >
                        <Bookmark className="w-3 h-3 text-amber-400" />
                        <span>{savedToWatchlist ? 'Saved to Watchlist!' : 'Save to Watchlist'}</span>
                      </button>

                      <button
                        onClick={handleSetAlert}
                        className="px-2.5 py-1.5 rounded bg-[#00223B] border border-[#003B64] hover:border-slate-500 text-[11px] text-slate-300 flex items-center gap-1 transition-colors"
                      >
                        <Bell className="w-3 h-3 text-sky-400" />
                        <span>{alertSet ? 'Alert Enabled!' : 'Track Odds Shifts'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Success Modal */}
      {showConfirmationSuccess && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#00223B] border-2 border-emerald-500 rounded-2xl max-w-md w-full p-6 text-center shadow-2xl relative">
            <div className="w-12 h-12 bg-emerald-950 rounded-full flex items-center justify-center mx-auto mb-3 border border-emerald-500">
              <Check className="w-6 h-6 text-emerald-400" />
            </div>

            <span className="bg-emerald-900/60 text-emerald-300 text-[11px] font-bold px-2.5 py-1 rounded-full border border-emerald-700">
              Confident Action Recorded
            </span>

            <h3 className="text-xl font-black text-white mt-3 mb-1">
              Listić Uspješno Uplaćen!
            </h3>
            <p className="text-xs text-slate-300 mb-4">
              Your action was submitted with full transparency and zero hidden terms.
            </p>

            <div className="bg-[#001726] p-3 rounded-lg border border-[#003B64] text-xs text-left space-y-1.5 mb-4">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Stake:</span>
                <span className="font-mono text-white font-bold">€{stake.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Net Payout:</span>
                <span className="font-mono text-emerald-400 font-bold">€{netReturn.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Session Quality Index Impact:</span>
                <span className="font-mono text-sky-400 font-bold">+10 pts (High Intent)</span>
              </div>
            </div>

            <button
              onClick={() => setShowConfirmationSuccess(false)}
              className="w-full bg-[#005088] hover:bg-[#0060A0] text-white py-2.5 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              Continue Exploring PSK.hr
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
