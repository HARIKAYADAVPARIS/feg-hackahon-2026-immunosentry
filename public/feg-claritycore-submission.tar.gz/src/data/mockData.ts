import { SportsMatch } from '../types';

export const SAMPLE_MATCHES: SportsMatch[] = [
  {
    id: 'm1',
    league: 'SuperSport HNL (Croatia)',
    country: 'Croatia',
    sport: 'football',
    homeTeam: 'GNK Dinamo Zagreb',
    awayTeam: 'HNK Hajduk Split',
    time: 'Tonight 20:00 CEST',
    isLive: false,
    odds: {
      home: 1.85,
      draw: 3.40,
      away: 4.20,
      over25: 1.92,
      under25: 1.88,
      bttsYes: 1.80,
      bttsNo: 1.95,
    },
    clarityInsights: {
      tag: 'Derby Insight',
      summary: 'Dinamo has won 4 of the last 5 Eternal Derbies at Maksimir with an average of 2.6 goals.',
      statFact: 'Maksimir Fortress: Dinamo conceded only 0.7 goals per home match this season.',
      confidenceGrade: 'A',
      fairValueAssessment: 'Home Win (1.85) aligns with historical home conversion model; moderate volatility.',
    },
    h2hStats: {
      homeRecent: ['W', 'W', 'D', 'W', 'W'],
      awayRecent: ['W', 'L', 'W', 'D', 'W'],
      lastMeeting: 'Dinamo 2 - 1 Hajduk (April 2024)',
    },
  },
  {
    id: 'm2',
    league: 'UEFA Champions League',
    country: 'Europe',
    sport: 'football',
    homeTeam: 'Real Madrid',
    awayTeam: 'Bayern Munich',
    time: 'Tomorrow 21:00 CEST',
    isLive: false,
    odds: {
      home: 2.10,
      draw: 3.60,
      away: 3.20,
      over25: 1.65,
      under25: 2.25,
      bttsYes: 1.55,
      bttsNo: 2.35,
    },
    clarityInsights: {
      tag: 'Tactical Form',
      summary: 'High-octane European knockout tie; both teams scored in 9 of their last 10 UCL encounters.',
      statFact: 'Both Teams to Score (1.55) historically hit in 88% of semifinal legs between these giants.',
      confidenceGrade: 'A',
      fairValueAssessment: 'Both Teams to Score carries high liquidity and statistically balanced expected value.',
    },
    h2hStats: {
      homeRecent: ['W', 'W', 'W', 'D', 'W'],
      awayRecent: ['W', 'W', 'D', 'W', 'L'],
      lastMeeting: 'Bayern 2 - 2 Real Madrid (Leg 1)',
    },
  },
  {
    id: 'm3',
    league: 'SuperSport HNL (Croatia)',
    country: 'Croatia',
    sport: 'football',
    homeTeam: 'HNK Rijeka',
    awayTeam: 'NK Osijek',
    time: 'Live 64\'',
    isLive: true,
    liveMinute: '64\'',
    score: '1 - 0',
    odds: {
      home: 1.38,
      draw: 4.10,
      away: 8.50,
      over25: 2.15,
      under25: 1.62,
    },
    clarityInsights: {
      tag: 'In-Play Momentum',
      summary: 'Rijeka controlling 61% possession with 8 shots on target. Osijek operating with a low block.',
      statFact: 'Under 2.5 Goals (1.62) has landed in 75% of second halves where Rijeka led 1-0 at 60\'.',
      confidenceGrade: 'B+',
      fairValueAssessment: 'Under 2.5 goals represents conservative in-play consistency.',
    },
    h2hStats: {
      homeRecent: ['W', 'D', 'W', 'W', 'L'],
      awayRecent: ['L', 'D', 'W', 'L', 'D'],
      lastMeeting: 'Osijek 0 - 1 Rijeka',
    },
  },
  {
    id: 'm4',
    league: 'English Premier League',
    country: 'England',
    sport: 'football',
    homeTeam: 'Arsenal FC',
    awayTeam: 'Chelsea FC',
    time: 'Saturday 18:30 BST',
    isLive: false,
    odds: {
      home: 1.70,
      draw: 3.90,
      away: 4.60,
      over25: 1.75,
      under25: 2.05,
      bttsYes: 1.72,
      bttsNo: 2.08,
    },
    clarityInsights: {
      tag: 'London Derby Analysis',
      summary: 'Arsenal have scored in 14 consecutive home games; Chelsea showing high counter-attack threat.',
      statFact: 'Arsenal home xG is 2.34 vs Chelsea away expected goals allowed of 1.71.',
      confidenceGrade: 'A',
      fairValueAssessment: 'Arsenal Win (1.70) backed by league-leading home defensive record.',
    },
    h2hStats: {
      homeRecent: ['W', 'W', 'W', 'W', 'D'],
      awayRecent: ['W', 'D', 'W', 'L', 'W'],
      lastMeeting: 'Arsenal 5 - 0 Chelsea',
    },
  },
  {
    id: 'm5',
    league: 'ATP Masters 1000',
    country: 'International',
    sport: 'tennis',
    homeTeam: 'Carlos Alcaraz',
    awayTeam: 'Jannik Sinner',
    time: 'Sunday 16:00 CEST',
    isLive: false,
    odds: {
      home: 1.95,
      away: 1.85,
    },
    clarityInsights: {
      tag: 'Peak Rivalry',
      summary: 'Evenly matched head-to-head (4-4); 6 out of 8 career matches have gone the full distance in sets.',
      statFact: 'Over 22.5 Games or 3-Set contest has occurred in 75% of their hard-court meetings.',
      confidenceGrade: 'Balanced',
      fairValueAssessment: 'Tight margins; high entertainment value for tennis aficionados.',
    },
    h2hStats: {
      homeRecent: ['W', 'W', 'W', 'W', 'W'],
      awayRecent: ['W', 'W', 'W', 'W', 'W'],
      lastMeeting: 'Alcaraz 3 - 2 Sinner (Roland Garros)',
    },
  },
];

export const STAGE_CREDENTIALS_INFO = {
  stageUrl: 'https://www-dc1.stage.psk.hr/',
  prodUrl: 'https://www.psk.hr/',
  totalUsers: 60,
  exampleUser: 'HackathonSTG01',
  examplePassword: 'Hackathon01',
  userRange: 'HackathonSTG01 to HackathonSTG60',
  passwordRule: 'Replace STG with empty string (e.g. HackathonSTG25 -> Hackathon25)',
};

export interface FEGMarket {
  id: string;
  country: string;
  flag: string;
  brand: string;
  domain: string;
  monthlySessions: string;
  status: string;
  taxLaw: string;
}

export const FEG_CORPORATE_PROFILE = {
  name: 'Fortuna Entertainment Group (FEG)',
  website: 'https://www.feg.eu',
  tagline: 'The Largest Central European Betting Operator',
  scale: '6,000+ Employees Across Europe & FEG India GCC (Hyderabad)',
  markets: [
    {
      id: 'hr',
      country: 'Croatia',
      flag: '🇭🇷',
      brand: 'PSK (Prva Sportska Kladionica)',
      domain: 'psk.hr',
      monthlySessions: '2.4M',
      status: 'Live Pilot Focus',
      taxLaw: 'Zakon o igrama na sreću (10% statutory winnings tax)',
    },
    {
      id: 'cz',
      country: 'Czech Republic',
      flag: '🇨🇿',
      brand: 'Fortuna CZ (Founding Brand)',
      domain: 'ifortuna.cz',
      monthlySessions: '3.1M',
      status: 'Phase 2 Rollout',
      taxLaw: 'Czech Gambling Act No. 186/2016',
    },
    {
      id: 'sk',
      country: 'Slovakia',
      flag: '🇸🇰',
      brand: 'Fortuna SK',
      domain: 'ifortuna.sk',
      monthlySessions: '1.8M',
      status: 'Phase 2 Rollout',
      taxLaw: 'Slovak Gambling Act No. 30/2019',
    },
    {
      id: 'pl',
      country: 'Poland',
      flag: '🇵🇱',
      brand: 'Fortuna PL',
      domain: 'efortuna.pl',
      monthlySessions: '2.2M',
      status: 'Phase 3 Rollout',
      taxLaw: 'Polish Ustawa o grach hazardowych',
    },
    {
      id: 'ro',
      country: 'Romania',
      flag: '🇷🇴',
      brand: 'Fortuna & Casa Pariurilor',
      domain: 'efortuna.ro / casapariurilor.ro',
      monthlySessions: '2.5M',
      status: 'Phase 3 Rollout',
      taxLaw: 'ONJN Romanian Gambling Directives',
    },
  ] as FEGMarket[],
};

