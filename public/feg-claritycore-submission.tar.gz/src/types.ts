export type ActiveView = 'prototype' | 'demo' | 'impact' | 'compliance' | 'pitch';

export type UserPersona = 'casual' | 'analytical' | 'responsible_check';

export interface SportsMatch {
  id: string;
  league: string;
  country: string;
  sport: 'football' | 'basketball' | 'tennis';
  homeTeam: string;
  awayTeam: string;
  time: string;
  isLive: boolean;
  liveMinute?: string;
  score?: string;
  odds: {
    home: number;
    draw?: number;
    away: number;
    over25?: number;
    under25?: number;
    bttsYes?: number;
    bttsNo?: number;
  };
  clarityInsights: {
    tag: string;
    summary: string;
    statFact: string;
    confidenceGrade: 'A' | 'B+' | 'Balanced';
    fairValueAssessment: string;
  };
  h2hStats: {
    homeRecent: string[];
    awayRecent: string[];
    lastMeeting: string;
  };
}

export interface BetslipItem {
  matchId: string;
  matchTitle: string;
  selection: string;
  odds: number;
  marketName: string;
  clarityNote: string;
}

export interface SessionMetrics {
  sessionDurationSec: number;
  pagesViewed: number;
  actionsCompleted: number;
  sqiScore: number; // 0 - 100 Session Quality Index
  frictionPointsAvoided: number;
  confidenceIndicator: number; // 0 - 100
  rgHealthStatus: 'Optimal' | 'Caution' | 'Cool-down Active';
}

export interface ImpactModelInputs {
  monthlySessions: number; // e.g. 12,000,000 across FEG CEE
  baselineConversionRate: number; // e.g. 14.2%
  projectedConversionUplift: number; // e.g. +3.8%
  averageActionValue: number; // e.g. €8.50
  finalStepAbandonmentBaseline: number; // e.g. 38%
  finalStepRecoveryRate: number; // e.g. 24%
  retentionD90Uplift: number; // e.g. +6.5%
}
